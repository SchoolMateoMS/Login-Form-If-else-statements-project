// detects if btn is pressed, then activates function "Login"
document.getElementById("btn").addEventListener("click", Login);

// function Login, contains all the code
function Login() {
    // make variables, and get them to linked to html
    let UsernameJ = document.getElementById("UsernameInput").value;

    let PasswordJ = document.getElementById("Password").value;


    // see if the username and password is correct
    if (UsernameJ === "admin" && PasswordJ === "1234") {
        alert("Login Succesfull");
        // if the username is anything other than admin, it says that that username is incorrect
    } else if (UsernameJ !== "admin") {
        alert("Invalid Username");
        // if password is incorrect it displays Invalid Password
    } else if (PasswordJ !== "1234") {
        alert("Invalid Password");
    }
}